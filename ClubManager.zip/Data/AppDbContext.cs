using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ClubManager.Models;

namespace ClubManager.Data
{
    public class AppDbContext : IdentityDbContext<ApplicationUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Event> Events { get; set; }
        public DbSet<Club> Clubs { get; set; }

        public DbSet<Student> Students { get; set; }

        public DbSet<Membership> Memberships { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Cấu hình quan hệ nhiều-nhiều giữa Student và Club qua Membership
            builder.Entity<Membership>()
                .HasKey(m => m.Id);

            builder.Entity<Membership>()
                .HasOne(m => m.Student)
                .WithMany(s => s.Memberships)
                .HasForeignKey(m => m.StudentId);

            builder.Entity<Membership>()
                .HasOne(m => m.Club)
                .WithMany(c => c.Memberships)
                .HasForeignKey(m => m.ClubId);
        }
    }
}

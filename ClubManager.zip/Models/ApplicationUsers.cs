using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ClubManager.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        public string FullName { get; set; }

        public string Class { get; set; }

        public string RoleInClub { get; set; }  // Ví dụ: "Thành viên", "Trưởng CLB", "Thư ký"

        public DateTime JoinDate { get; set; } = DateTime.Now;
    }
}
